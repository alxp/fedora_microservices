'''
Created on 2010-07-19

@author: Alexander O'Neill
'''

LISTENERS = {}
