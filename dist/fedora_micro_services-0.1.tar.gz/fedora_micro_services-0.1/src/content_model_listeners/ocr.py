'''
Created on 2010-07-27

@author: aoneill
'''


import tempfile, os, subprocess
import fcrepo.connection
from shutil import rmtree
from fcrepo.client import FedoraClient
from fcrepo.utils import NS

abbyy_cli_home = '/usr/local/ABBYYData/FRE80_M5_Linux_part_498-28_build_8-1-0-7030/Samples/CLI/'

def do_ocr(obj):
    """
    Create XML, PDF and TXT streams for an image stream and add them to the Fedora object.
    """
    global abbyy_cli_home
    d = tempfile.mkdtemp()
    cwd = os.getcwd()
    os.chdir(d)
    
    if 'JP2' in obj:
        f = open(d+'/tmpfile.jp2', 'w')
        f.write(obj['JP2'].getContent().read())
        f.close()
        # Now do the conversion to get a TIFF
        subprocess.call(["kdu_expand", "-i", "tmpfile.jp2", "-o", "tmpfile.tiff"])
    elif 'TIFF' in obj:
        f = open(d+'/tmpfile.tiff', 'w')
        f.write(obj['TIFF'].getContent().read())
        f.close()        
    
    if os.path.exists('tmpfile.tiff'):
        # Perform the OCR using ABBYY FnieReaderr  
        os.chdir(abbyy_cli_home)
        subprocess.call(["./CLI", "-ics", "-if", "%(dir)s/tmpfile.tiff" % {'dir': d}, "-f", "PDF", "-pem", "ImageOnText", 
                         "-pfpf", "Automatic", "-pfq", "90", "-pfpr", "150", "-of", "%(dir)s/tmpfile.pdf" % {'dir': d},
                         "-f", "XML", "-xaca", "-of", "%(dir)s/tmpfile.xml" % {'dir': d}, 
                         "-f", "Text", "-tel", "-tpb", "-tet", "UTF8", "-of", "%(dir)s/tmpfile.txt" % {'dir': d}])
        subprocess.call(["ls", "-l", d]) 
        
        txt_file = open('%(dir)s/tmpfile.txt' % {'dir': d}, 'r')
        if 'OCR' not in obj:
            obj.addDataStream('OCR', mimetype='text/plain')
        obj['OCR'].setContent(txt_file)
        txt_file.close()
        
        xml_file = open('%(dir)s/tmpfile.xml' % {'dir': d}, 'r')
        if 'ABBYY_XML' not in obj:
            obj.addDataStream('ABBYY_XML', mimetype='text/xml')
        obj['ABBYY_XML'].setContent(xml_file)
        xml_file.close()
        
        pdf_file = open('%(dir)s/tmpfile.pdf' % {'dir': d}, 'r')
        if 'PagePDF' not in obj:
            obj.addDataStream('PagePDF', mimetype='text/pdf')
        obj['PagePDF'].setContent(pdf_file)
        pdf_file.close()
                
    rmtree(d, ignore_errors = True)        
    os.chdir(cwd)
    return obj