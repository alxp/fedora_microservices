'''
Created on 2010-07-12

@author: Alexander O'Neill
'''

import base64
import os
import sys
import time
import tempfile

from optparse import OptionParser

from stomp.connect import Connection
import feedparser
from stomp.listener import ConnectionListener, StatsListener
from stomp.exception import NotConnectedException

import fcrepo.connection
from fcrepo.client import FedoraClient
from fcrepo.utils import NS

def sysout(msg, end='\n'):
    sys.stdout.write(str(msg) + end)    

class StompFedora(ConnectionListener):
    """
    A custom interface to the stomp.py client. See \link stomp::internal::connect::Connection \endlink
    for more information on establishing a connection to a stomp server.
    """
    def __init__(self, host='localhost', port=61613, user='', passcode='', fedora_url=''):
        self.conn = Connection([(host, port)], user, passcode)
        self.conn.set_listener('', self)
        self.conn.start()
        self.transaction_id = None
        self.fc = fcrepo.connection.Connection(fedora_url, username = user, password = passcode)
        self.client = FedoraClient(self.fc)
        
    def __print_async(self, frame_type, headers, body):
        """
        Utility function for printing messages.
        """
        sysout("\r  \r", end='')
        sysout(frame_type)
        for header_key in headers.keys():
            sysout('%s: %s' % (header_key, headers[header_key]))
        sysout('')
        sysout(body)
        sys.stdout.flush()
        
    def __get_content_models(self, pid):
        """
        Get a list of content models that apply to the object.
        """
        obj = self.client.getObject(pid)
        ds = obj['RELS-EXT']
        
        return [elem['value'].split('/')[1] for elem in ds[NS.fedoramodel.hasModel]]
        
    def on_connecting(self, host_and_port):
        """
        \see ConnectionListener::on_connecting
        """
        self.conn.connect(wait=True)
        
    def on_disconnected(self):
        """
        \see ConnectionListener::on_disconnected
        """
        sysout("lost connection")
        
    def on_message(self, headers, body):
        """
        \see ConnectionListener::on_message
        """
        self.__print_async("MESSSAGE", headers, body)
        f = feedparser.parse(body)
        tags = f['entries'][0]['tags']
        pid = [tag['term'] for tag in tags if tag['scheme'] == 'fedora-types:pid'][0]
        dsIDs = [tag['term'] for tag in tags if tag['scheme'] == 'fedora-types:dsID']
        content_models = self.__get_content_models(pid) # and 'OBJ' in dsIDs:
        for content_model in content_models:
            print "/topic/fedora.contentmodel.%s" % content_model
            self.send("/topic/fedora.contentmodel.%s" % content_model, '', body)
        
    def on_error(self, headers, body):
        """
        \see ConnectionListener::on_error
        """
        self.__print_async("ERROR", headers, body)
        
    def on_connected(self, headers, body):
        """
        \see ConnectionListener::on_connected
        """
        self.__print_async("CONNECTED", headers, body)
        
    def ack(self, args):
        """
        Required Parameters:
            message-id - the id of the message being acknowledged
        
        Description:
            Acknowledge consumption of a message from a subscription using client
            acknowledgement. When a client has issued a subscribe with an 'ack' flag set to client
            received from that destination will not be considered to have been consumed  (by the server) until
            the message has been acknowledged.
        """
        if not self.transaction_id:
            self.conn.ack(headers = { 'message-id' : args[1]})
        else:
            self.conn.ack(headers = { 'message-id' : args[1]}, transaction=self.transaction_id)
        
    def abort(self, args):
        """
        Description:
            Roll back a transaction in progress.
        """
        if self.transaction_id:
            self.conn.abort(transaction=self.transaction_id)
            self.transaction_id = None
    
    def begin(self, args):
        """
        Description
            Start a transaction. Transactions in this case apply to sending and acknowledging
            any messages sent or acknowledged during a transaction will be handled atomically based on teh
            transaction.
        """
        if not self.transaction_id:
            self.transaction_id = self.conn.begin()
    
    def commit(self, args):
        """
        Description:
            Commit a transaction in progress.
        """
        if self.transaction_id:
            self.conn.commit(transaction=self.transaction_id)
            self.transaction_id = None
    
    def disconnect(self, args):
        """
        Description:
            Gracefully disconnect from the server.
        """
        try:
            self.conn.disconnect()
        except NotConnectedException:
            pass
    
    def send(self, destination, correlation_id, message):
        """
        Required Parametes:
            destination - where to send the message
            message - the content to send
            
        Description:
        Sends a message to a destination in the message system.
        """
        self.conn.send(destination=destination, message=message, headers={'correlation-id': correlation_id})
        
    def subscribe(self, destination, ack='auto'):
        """
        Required Parameters:
            destination - the name to subscribe to
            
        Optional Parameters:
            ack - how to handle acknowledgements for a message, either automatically (auto) or manually (client)
            
        Description
            Register to listen to a given destination. Like send, the subscribe command requires a destination
            header indicating which destination to subscribe to.  The ack parameter is optional, and defaults to auto.
        """
        self.conn.subscribe(destination=destination, ack=ack)
        
    def unsubscribe(self, destination):
        """
        Required Parameters:
            destination - the name to unsubscribe from
        
        Description:
            Remove an existing subscription - so that the client no longer receives messages from that destination.
        """
        self.conn.unsubscribe(destination)
        
        

if __name__ == '__main__':
    parser = OptionParser()
    
    parser.add_option('-H', '--host', type = 'string', dest = 'host', default = 'localhost',
                      help = 'Hostname or IP to connect to. Defaults to localhost if not specified.')
    parser.add_option('-P', '--port', type = int, dest = 'port', default = 61613,
                      help = 'Port providing stomp protocol connections. Defaults to 61613 if not specified.')
    parser.add_option('-U', '--user', type = 'string', dest = 'user', default = None,
                      help = 'Username for the connection')
    parser.add_option('-W', '--password', type = 'string', dest = 'password', default = None,
                      help = 'Password for the connection')
    parser.add_option('-R', '--fedoraurl', type = 'string', dest = 'fedoraurl', default = 'http://localhost:8080/fedora',
                      help = 'Fedora URL. Defaults to http://localhost:8080/fedora')
    
    (options, args) = parser.parse_args()
    sf = StompFedora(options.host, options.port, options.user, options.password, options.fedoraurl)
    
    sf.subscribe('/topic/fedora.apim.update')
    while True:
        time.sleep(2)
    